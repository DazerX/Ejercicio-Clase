
package ejercicioclase;



public class Main {

    public static void main(String[] args) {
      FacturaCredito fa = new FacturaCredito(2000);
      FacturaContado fc = new FacturaContado("efectivo",3200);
      
        System.out.println(fa.toString());
        System.out.println(fc.toString());
        System.out.println(fa.calcularPago());
    }
    
}
