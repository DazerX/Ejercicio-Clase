
package ejercicioclase;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class FacturaCredito extends Factura {
    private LocalDate fechaPlazo;

    public FacturaCredito( double valor) {
        super(valor);
        this.fechaPlazo =super.getFecha().plusDays(90);
    }

    public LocalDate getFechaPlazo() {
        return fechaPlazo;
    }

    public void setFechaPlazo(LocalDate fechaPlazo) {
        this.fechaPlazo = fechaPlazo;
    }

    @Override
    public String toString() {
        return "FacturaCredito{" + "fechaPlazo=" +" "+ fechaPlazo +super.toString()+ '}';
    }
    

    @Override
    public double calcularPago() {
        LocalDate fechaActual = super.getFecha().plusDays(31);
        System.out.println("Fecha  "+fechaActual);
        long dias = ChronoUnit.DAYS.between(this.fechaPlazo, fechaActual);
        if(dias>=0 || dias<=30 ){
            double incremento = super.getValor()*0.05;
            super.setValor(super.getValor()+incremento);
            return super.getValor();
        }
        if(dias>30 || dias<=60){
            double incremento = super.getValor()*0.1;
            super.setValor(super.getValor()+incremento);
            return super.getValor();
        }
         if(dias>60 || dias<=90){
            double incremento = super.getValor()*0.2;
            super.setValor(super.getValor()+incremento);
            return super.getValor();
         }
        if(dias>90){
            System.out.println("Estas reportado en DataCredito papi :/");
        }   
        return 0;
    } 
    
    
    
}
