
package ejercicioclase;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class FacturaContado extends Factura {
    private String medioPago;

    public FacturaContado(String medioPago, double valor) {
        super(valor);
        this.medioPago = medioPago;
    }

    public String getMedioPago() {
        return medioPago;
    }

    public void setMedioPago(String medioPago) {
        this.medioPago = medioPago;
    }

    @Override
    public String toString() {
        return "FacturaContado{" + "medioPago=" + medioPago + super.toString()+ '}';
    }

    @Override
    public double calcularPago() {
        LocalDate fechaBeneficio = super.getFecha().plusDays(10);
        long dias = ChronoUnit.DAYS.between(fechaBeneficio, super.getFecha());
        if(dias<=5){
            double descuento = super.getValor()*0.1;
            super.setValor(super.getValor()-descuento);
        }
        if(dias>5 || dias<=10){
            double descuento = super.getValor()*0.05;
            super.setValor(super.getValor()-descuento);
        }
        return super.getValor();
        
    }
    
}
