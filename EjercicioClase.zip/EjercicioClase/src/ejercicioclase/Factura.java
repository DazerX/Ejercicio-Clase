
package ejercicioclase;

import java.time.LocalDate;

public abstract class Factura{
    private static int consecutivo=0;
    private int noFactura;
    private LocalDate fecha;
    private double valor;

    public Factura(double valor) {
        this.fecha =LocalDate.now();
        this.valor=valor;
        consecutivo++;
        this.noFactura=consecutivo;
    }

    public static int getConsecutivo() {
        return consecutivo;
    }

    public static void setConsecutivo(int consecutivo) {
        Factura.consecutivo = consecutivo;
    }

    public int getNoFactura() {
        return noFactura;
    }

    public void setNoFactura(int noFactura) {
        this.noFactura = noFactura;
    }

    


    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return ", nFactura=" + noFactura + ", fecha inicial=" + fecha + ", valor=" + valor+", valor a pagar= "+this.calcularPago() ;
    }
    public abstract double calcularPago();
    
    
}
